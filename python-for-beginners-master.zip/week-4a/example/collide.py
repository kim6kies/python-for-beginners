def collide():
    print("In example/collide.py::collide()")
