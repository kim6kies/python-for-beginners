print("\nFile Name: {}\nModule Name: {}".format( __file__, __name__))

print("Symbol Table {}\n{}:".format(__file__, dir())) # names in current scope

syntax error  # invalid python statement
