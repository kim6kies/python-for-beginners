print("In sound/format/__init__.py.")
__all__ = ['wave']
