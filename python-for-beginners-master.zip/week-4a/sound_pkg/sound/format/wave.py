def encode():
    print("In wave.py, encode()")


def decode():
    print("In wave.py, decode()")
