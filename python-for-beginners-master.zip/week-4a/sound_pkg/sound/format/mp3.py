def encode():
    print("In mp3.py, encode()")


def decode():
    print("In mp3.py, decode()")

def read_mp3():
    print("In mp3.py, read_mp3()")

def write_mp3():
    print("In mp3.py, write_mp3()")
