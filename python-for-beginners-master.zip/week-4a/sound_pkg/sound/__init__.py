print("In sound/__init__.py")

__all__ = ['audio']
print("In sound/__init__.py, __all__ = {}".format(__all__))

