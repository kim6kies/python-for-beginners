print("In sound/filters/equalizer.py, dir() {}".format(dir()))

def equalizer():
    print("In equalizer.py, equalizer()")
