print("In sound/effects/__init__.py")
