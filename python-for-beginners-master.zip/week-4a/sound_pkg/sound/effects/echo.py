print("In sound/effects/echo.py")

def echo():
    print("In sound/effects/echo.py::echo()")
