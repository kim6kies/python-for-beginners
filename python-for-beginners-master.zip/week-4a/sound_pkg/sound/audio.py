print("In sound/audio.py")

def audio_func():
    print("In sound/audio.py, in audio()")
