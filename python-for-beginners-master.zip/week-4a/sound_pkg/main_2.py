print("In main_2.py, import sound.audio")

import sound.audio  # importing package.module

print("In main_2.py, dir(): {}".format(dir()))
print("In main_2.py, dir(sound.audio): {}".format(dir(sound.audio)))
print("In main_2.py, calling sound.audio.audio()")
sound.audio.audio()
