print("In main_9.py, import sound.effects.sur_absolute as sur")
import sound.effects.sur_absolute as sur  # renaming package.subpackage.module as sur

print("In main_9.py, dir(): ", dir())
print("In main_9.py, calling sur.surround()")
sur.surround()
