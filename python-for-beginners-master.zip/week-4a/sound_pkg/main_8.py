print("In main_8.py, import sound.effects.surround as sur")
import sound.effects.surround as sur  # renaming package.subpackage.module as sur

print("In main_8.py, dir(): ", dir())
print("In main_8.py, calling sur.surround()")
sur.surround()
