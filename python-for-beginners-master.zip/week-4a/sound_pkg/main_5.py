print("In main_5.py, from sound.format.wave import encode")
from sound.format.wave import encode  # importing function encode

print("In main_5.py, dir(): {}".format(dir()))
print("In main_5.py, calling encode()")

encode()
