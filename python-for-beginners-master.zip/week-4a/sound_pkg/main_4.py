print("In main_4.py, import sound.format.wave")

import sound.format.wave   # absolute path

print("In main_4.py, dir():{}".format(dir()))
print("In main_4.py, calling sound.format.wave.encode()")
sound.format.wave.encode()
