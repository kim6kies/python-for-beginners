print("In main_7.py, import sound.format.wave as wav")
import sound.format.wave as wav    # rename package.subpackage.module as wav

print("In main_7.py, dir(): {}".format(dir()))
print("In main_7.py, calling wav.encode()")

wav.encode()
