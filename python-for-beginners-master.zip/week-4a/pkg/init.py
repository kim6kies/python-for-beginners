print("In pkg/__init__.py")

import pkg.mod1