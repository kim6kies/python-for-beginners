def baz():
    print('[pkg] baz()')
