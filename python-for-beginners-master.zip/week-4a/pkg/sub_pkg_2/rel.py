from ..sub_pkg_1.mod1 import foo

def spam():
    print("In pkg/sub_pkg_2/rel.py::spam()")
    foo()
