def eggs():
    print("In pkg/sub_pkg_2/mod4.py::eggs()")
