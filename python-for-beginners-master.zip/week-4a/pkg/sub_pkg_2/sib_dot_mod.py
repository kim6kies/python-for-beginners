from .mod4 import eggs

def spam():
    print("In pkg/sub_pkg_2/sib_dot_mod.py::spam()")
    eggs()
