def spam():
    print("In pkg/sub_pkg_2/mod3.py::spam()")
