from . import mod4

def spam():
    print("In pkg/sub_pkg_2/sib_dot.py::spam()")
    mod4.eggs()
