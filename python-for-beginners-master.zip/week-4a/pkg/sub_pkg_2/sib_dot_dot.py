from .. import mod5

def spam():
    print("In pkg/sub_pkg_2/sib_dot_dot.py::spam()")
    mod5.baz()