def foo():
    print("In pkg/sub_pkg_1/mod1.py::foo()")
