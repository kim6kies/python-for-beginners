def bar():
    print("In pkg/sub_pkg_1/mod2.py::bar()")
