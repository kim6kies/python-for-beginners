print("In pkg/__init__.py")

__all__ = [ 'mod1' ]