
__all__ = ['spam']

def spam():
    print("In mod3.py::spam()")

def eggs():
    print("In mod3.py::eggs()")