def bar():
    print('[mod2] bar()')
